# MIAhackathon2024
Repository for the DIKU MIA group participation in the [MICCAI E2MIP challenge](https://e2mip.org/data/) in 2024.

A nice description of the MIA hackathon was made [here](https://alejandrocortina.notion.site/MIA-HACKATHON-E2MIP-eef8be9fbfe64212b309066960eb63b0)
