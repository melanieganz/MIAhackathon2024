#!/bin/bash
python3 train_mobilenet.py 