#!/bin/bash
python3 test.py 